# CS289a - HW3

Name: John Semerdjian

SID: 16701389

## Instructions

I completed the assignment in an IPython notebook, `CS289a - HW3.ipynb`, and also converted it to a separate a python file, `CS289a - HW3.py`. Running my code through IPython is preferred.

All code was run on Python 3.4.2.

```bash
# create a virtual environment, "cs289-hw3"
$ mkvirtualenv --python=/usr/local/bin/python3 cs289-hw3

# install required modules
$ pip install -r requirements.txt

# start ipython notebook (preferred)
$ workon cs289-hw3
$ ipython notebook

# or run .py file directly
$ workon cs289-hw3
$ python CS289a\ -\ HW1.py
```
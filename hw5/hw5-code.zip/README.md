# CS289a - HW5

Name: John Semerdjian

SID: 16701389

## Instructions

I completed the assignment in an IPython notebook, `CS289a - HW5.ipynb`, which calls code from three Python files: `Node.py`, `DecisionTree.py`, and `RandomForest.py`.

All code was run on Python 3.4.2.

```bash
# create a virtual environment, "cs289-hw5"
$ mkvirtualenv --python=/usr/local/bin/python3 cs289-hw5

# install required modules
$ pip install -r requirements.txt

# start ipython notebook
$ workon cs289-hw5
$ ipython notebook
```
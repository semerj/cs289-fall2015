# CS289a - HW1

Name: John Semerdjian

SID: 16701389

## Instructions

I completed the assignment in an IPython notebook, `CS289a - HW1.ipynb`, and also converted it to a separate a python file, `CS289a - HW1.py`. Running my code through IPython is preferred.

The code to run my Kaggle submission models is also included in both files, but the code to save my predictions to CSV have been commented out.

All code was run on Python 2.7.10.

```bash
# create a virtual environment, cs289
$ mkvirtualenv --python=/usr/local/bin/python2 cs289

# install required modules
$ pip install -r requirements.txt

# start ipython notebook (preferred)
$ ipython notebook

# or run .py file directly
$ python CS289a\ -\ HW1.py
```
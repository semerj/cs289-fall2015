# CS289a - HW7

Name: John Semerdjian

SID: 16701389

## Instructions

I completed the assignment in an IPython notebook, `CS289a - HW7.ipynb`, which from the following Python files: `KMeans.py`, `KNN.py`, `ALSLatentFactorModel.py`, `eigenface_utils.py`, and `utils.py`.

All code was run on Python 3.4.2.

```bash
# create a virtual environment, "cs289-hw7"
$ mkvirtualenv --python=/usr/local/bin/python3 cs289-hw7

# install required modules
$ pip install -r requirements.txt

# start ipython notebook
$ workon cs289-hw7
$ ipython notebook
```
